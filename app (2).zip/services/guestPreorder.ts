// services/guestPreorder.ts
import { useRuntimeConfig, useCookie } from '#imports'

/**
 * Fire-and-forget гостевой pre-order.
 * Ошибки глушим — лид не теряем, UI не блокируем.
 */
export function sendGuestPreorderFireAndForget (params: {
  sessionId: string
  fullName?: string
  phone?: string
}) {
  const { sessionId, fullName = '', phone = '' } = params
  const config = useRuntimeConfig()
  const baseURL = (config.public as any).apiBase || config.public?.baseUrl || ''

  // ничего не ждём
  ;(async () => {
    try {
      await $fetch(`/v1/shop/guest-cart/${encodeURIComponent(sessionId)}/pre-order`, {
        baseURL,
        method: 'POST',
        body: {
          name: fullName?.trim?.() || '',
          phone: String(phone || '').replace(/\D/g, ''),
        }
      })
    } catch (e) {
      if (process.dev) console.warn('[guest-preorder] ignored error', e)
    }
  })()
}

/** Утилита: получить/создать guest session id из cookie */
export function ensureGuestSessionId (): string {
  // имя куки поправь под свой бэкенд, если другое
  const c = useCookie<string | null>('guest_session_id', { sameSite: 'lax' })
  if (!c.value) {
    // простейший SID (uuid-подобный)
    c.value = Math.random().toString(36).slice(2) + Date.now().toString(36)
  }
  return c.value!
}
