import { defineNuxtPlugin, useRuntimeConfig } from '#imports'
import { useAuthStore } from '@/stores/authStore'

export default defineNuxtPlugin(() => {
  const config = useRuntimeConfig()
  const baseURL = (config.public as any).apiBase || config.public?.baseUrl || ''
  const auth = useAuthStore()

  const api = $fetch.create({
    baseURL,
    credentials: 'include',
    onRequest({ options }) {
      options.headers = options.headers || {}
      const token = auth.token
      if (token) (options.headers as any).Authorization = `Bearer ${token}`
    },
    async onResponseError({ request, options, response }) {
      // только при 401 и если есть refresh_token
      if (response?.status === 401 && auth.refreshToken) {
        const ok = await auth.tryRefresh()
        if (ok) {
          // повторяем исходный запрос с новым access
          options.headers = options.headers || {}
          ;(options.headers as any).Authorization = `Bearer ${auth.token}`
          return await $fetch(request, options)
        } else {
          auth.logout()
        }
      }
      throw response?._data || new Error('API error')
    }
  })

  return {
    provide: {
      api,              
      apiBase: baseURL,
    }
  }
})
