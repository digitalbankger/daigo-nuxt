<script setup lang="ts">
definePageMeta({ layout: 'main' })

import { computed, ref, onMounted, watch, defineAsyncComponent } from 'vue'
import { useRoute, useRouter, useSeoMeta } from '#imports'
import BaseContainer from '~/components/layout/BaseContainer.vue'
import ReviewCard from '~/components/reviews/ReviewCard.vue'
import MediaModal from '~/components/reviews/MediaModal.vue'
import type { Review } from '~/types/content'
import { useReviewsStore } from '~/stores/reviewsStore'

/* Ленивая модалка полного текста */
const ReviewTextModal = defineAsyncComponent(
  () => import('~/components/reviews/ReviewFullModal.vue')
)

/** поддерживаем и ваши текущие "daigo-*" и короткие слаги */
const TYPE_MAP: Record<string, { type: Review['type'], h1: string, seoTitle: string, seoDesc: string }> = {
  // видео
  'video':        { type: 'video',      h1: 'Видео отзывы',      seoTitle: 'Видео отзывы Daigo',      seoDesc: 'Смотрите видео-отзывы покупателей Daigo.' },
  'daigo-video':  { type: 'video',      h1: 'Видео отзывы',      seoTitle: 'Видео отзывы Daigo',      seoDesc: 'Смотрите видео-отзывы покупателей Daigo.' },

  // аудио
  'audio':        { type: 'audio',      h1: 'Аудио отзывы',      seoTitle: 'Аудио отзывы Daigo',      seoDesc: 'Слушайте аудио-отзывы покупателей Daigo.' },
  'daigo-audio':  { type: 'audio',      h1: 'Аудио отзывы',      seoTitle: 'Аудио отзывы Daigo',      seoDesc: 'Слушайте аудио-отзывы покупателей Daigo.' },

  // текст
  'text':         { type: 'text',       h1: 'Текстовые отзывы',  seoTitle: 'Текстовые отзывы Daigo',  seoDesc: 'Читайте текстовые отзывы покупателей Daigo.' },
  'daigo-text':   { type: 'text',       h1: 'Текстовые отзывы',  seoTitle: 'Текстовые отзывы Daigo',  seoDesc: 'Читайте текстовые отзывы покупателей Daigo.' },

  // «сторис» от известных людей (если понадобится отдельная страница)
  'celebrity':    { type: 'celebrity',  h1: 'Отзывы от известных людей', seoTitle: 'Отзывы от известных людей', seoDesc: 'Сторис и отзывы известных людей о Daigo.' },
}

const route = useRoute()
const router = useRouter()
const reviewsStore = useReviewsStore()

const isLoading = ref(true)
const loadError = ref<unknown>(null)

const conf = computed(() => TYPE_MAP[String(route.params.slug)])
if (!conf.value) {
  throw createError({ statusCode: 404, statusMessage: 'Подкатегория отзывов не найдена' })
}

/** загрузка данных без блокировки рендера */
onMounted(async () => {
  try {
    if (!reviewsStore.isLoaded) {
      await reviewsStore.loadAllReviews()
    }
  } catch (e) {
    loadError.value = e
  } finally {
    isLoading.value = false
  }
})

/** список по типу */
const list = computed<Review[]>(() =>
  (reviewsStore.allReviews ?? []).filter(r => r.type === conf.value.type)
)

/** ——— Пагинация по query ?page=N ——— */
const PAGE_SIZE = 12
const page = computed<number>(() => {
  const n = Number(route.query.page ?? 1)
  return Number.isFinite(n) && n > 0 ? n : 1
})
const totalPages = computed(() => Math.max(1, Math.ceil(list.value.length / PAGE_SIZE)))
const paginated = computed(() =>
  list.value.slice((page.value - 1) * PAGE_SIZE, page.value * PAGE_SIZE)
)
watch([list], () => {
  // если после загрузки текущая страница вышла за пределы — вернёмся на 1
  if (page.value > totalPages.value) {
    router.replace({ query: { ...route.query, page: 1 } })
  }
})

function go(p: number) {
  if (p < 1 || p > totalPages.value || p === page.value) return
  router.push({ query: { ...route.query, page: p } })
}

/** Модалка для видео/аудио/картинок (событие open-story) */
const selectedMedia = ref<Review | null>(null)
function openMedia(r: Review) { selectedMedia.value = r }

/** Модалка детального текста (событие open-text) */
const selectedTextReview = ref<Review | null>(null)
const isTextModalOpen = computed(() => !!selectedTextReview.value)
function openText(r: Review) { selectedTextReview.value = r }
function closeText() { selectedTextReview.value = null }

/** SEO / OG */
useSeoMeta({
  title: conf.value.seoTitle,
  description: conf.value.seoDesc,
  ogTitle: conf.value.seoTitle,
  ogDescription: conf.value.seoDesc,
  ogType: 'website',
  ogUrl: () => `https://daigo.ru${route.fullPath}`,
})
</script>

<template>
  <BaseContainer>
    <section class="relative w-full px-5">
      <h1 class="text-[clamp(2.4rem,6vw,3.4rem)] font-medium mb-8">
        {{ conf.h1 }}
      </h1>

      <div v-if="isLoading" class="text-center text-gray-500">Загружаем…</div>
      <div v-else-if="loadError" class="text-center text-red-500">Не удалось загрузить отзывы</div>

      <template v-else>
        <div v-if="!list.length" class="text-center text-gray-500">Пока нет отзывов.</div>

        <div v-else class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <ReviewCard
            v-for="r in paginated"
            :key="r.id"
            :review="r"
            @open-story="() => openMedia(r)"
            @open-text="openText"
          />
        </div>

        <!-- Пагинация -->
        <div v-if="totalPages > 1" class="flex items-center justify-center gap-2 mt-8">
          <button
            class="px-3 py-2 rounded border"
            :disabled="page <= 1"
            @click="go(page - 1)"
          >
            ← Назад
          </button>
          <span class="mx-2">Стр. {{ page }} из {{ totalPages }}</span>
          <button
            class="px-3 py-2 rounded border"
            :disabled="page >= totalPages"
            @click="go(page + 1)"
          >
            Вперёд →
          </button>
        </div>
      </template>

      <!-- Модалка медиа -->
      <ClientOnly>
        <MediaModal
          v-if="selectedMedia"
          :show="!!selectedMedia"
          :type="selectedMedia.video_url ? 'video' : selectedMedia.file_url ? 'audio' : 'image'"
          :src="selectedMedia.video_url || selectedMedia.file_url || selectedMedia.preview"
          :onClose="() => (selectedMedia = null)"
        />
      </ClientOnly>

      <!-- Модалка полного текста -->
      <ClientOnly>
        <ReviewTextModal
          :show="isTextModalOpen"
          :review="selectedTextReview"
          :onClose="closeText"
        />
      </ClientOnly>
    </section>
  </BaseContainer>
</template>
